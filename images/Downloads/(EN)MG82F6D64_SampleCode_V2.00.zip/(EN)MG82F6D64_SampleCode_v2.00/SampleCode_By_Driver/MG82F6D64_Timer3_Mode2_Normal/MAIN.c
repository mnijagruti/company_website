#include <intrins.h>
#include "REG_MG82F6D64.h"
#include "TYPEDEF.h"
#include "MG82F6D64_COMMON_DRV.h"
#include "MG82F6D64_GPIO_DRV.h"
#include "MG82F6D64_Timer_DRV.h"
#include "MG82F6D64_INT_DRV.h"
#include "MG82F6D64_INT_VECTOR.h"

/**
 ******************************************************************************
 * do-while template
 ******************************************************************************
 */
#define MWT( __stuff__ )  do { __stuff__ } while (0)

/****************************************************************
Variables
Timer3 overflow Interrupt(TH3) => TF3_Flag
Timer3 external Interrupt      => EXF3_Flag
Timer3 overflow Interrupt(TL3) => TF3L_Flag
****************************************************************/
uint8_t TF3_Flag, EXF3_Flag, TF3L_Flag;

void main()
{
    /****************************************************************
    Variables
    count       => For time delay
    ****************************************************************/
    uint16_t count = 0;

    /****************************************************************
     *  Interrupt Initialized
     *  1. Enable Timer3 interrupt (ET3) = Enable;
     *  2. Global enables all interrupts (EA) = Enable;
     ****************************************************************/
    __DRV_TIMER3_IT_Cmd(MW_ENABLE);
    __DRV_INT_ITEA_Enable();

    /****************************************************************
     *  GPIO Initialized
     *  1. P55 used for LED_D4
     ****************************************************************/
    __DRV_GPIO_P5ModeSelect(P55_PushPull);

    /****************************************************************
     *  Timer3 Initialized
     *  Interrupt time => (1 / (SYSCLK/12)) * 65536 * 15 = 0.983 S
     ****************************************************************/
    __DRV_TIMER3_Mode_Select(TIMER3_MODE2_16BIT_CAPTURE);
    __DRV_TIMER3_Clock_Source_Select(TIMER3_CLOCK_SOURCE_SYSCLK_DIV_12);
    __DRV_TIMER3_Run_Cmd(MW_ENABLE);

    while (1)
    {
        if (TF3_Flag)
        {
            count += 1;
            if (count == 15)
            {
                __DRV_GPIO_InversePinP5(P55);
                count = 0;
            }
            TF3_Flag = 0;
        }
    }
}

/****************************************************************
Timer3 interrupt
The Timer3 has TF3, EXF3, TF3L flags to trigger the Timer3 interrupt.
****************************************************************/
void TIMER3_TF3_EXF3_TF3L_ISR(void) interrupt TIMER3_ISR_VECTOR
{
    if (DRV_TIMER3_GetTF3() == 1)
    {
        TF3_Flag = 1;
        DRV_TIMER3_ClearTF3();
    }

    if (DRV_TIMER3_GetTF3L() == 1)
    {
        TF3L_Flag = 1;
        DRV_TIMER3_ClearTF3L();
    }

    if (DRV_TIMER3_GetEXF3() == 1)
    {
        EXF3_Flag = 1;
        DRV_TIMER3_ClearEXF3();
    }
}
