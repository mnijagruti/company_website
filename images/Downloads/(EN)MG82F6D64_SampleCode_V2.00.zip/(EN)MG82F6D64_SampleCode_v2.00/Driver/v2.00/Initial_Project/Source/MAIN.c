/**
 ******************************************************************************
 *
 * @file        MAIN.C
 *
 * @brief       This is the C code format main file.
 *
 * @par         Project
 *              MG82F6D64
 * @version     V1.00
 * @date        2020/09/15
 * @copyright   Copyright (c) 2019 MegaWin Technology Co., Ltd.
 *              All rights reserved.
 *
 ******************************************************************************
 * @par         Disclaimer
 *      The Demo software is provided "AS IF"  without any warranty, either
 *      expressed or implied, including, but not limited to, the implied warranties
 *      of merchantability and fitness for a particular purpose.  The author will
 *      not be liable for any special, incidental, consequential or indirect
 *      damages due to loss of data or any other reason.
 *      These statements agree with the world wide and local dictated laws about
 *      authorship and violence against these laws.
 ******************************************************************************
 ******************************************************************************
 */

#include "MG82F6D64_CONFIG.h"



void main ()
{

    System_Wizard_Init();


    while (1)
    {
        //code
    }

}
